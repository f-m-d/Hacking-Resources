'use strict';

const awesomeLint = require('awesome-lint');

awesomeLint.report({ filename: 'README.md'});
