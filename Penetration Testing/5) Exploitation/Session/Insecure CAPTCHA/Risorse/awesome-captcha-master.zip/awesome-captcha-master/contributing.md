# How to Contribute?

If you want to contribute to this list, feel free to do so by following these simple steps. Keep in mind that you should have consumed the content you want to contribute to this list.


## Make sure you agree to the license

Check out the `LICENSE` file and make sure you agree that you are comfortable with sharing your contributions to this list with that license.