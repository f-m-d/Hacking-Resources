# ReBreakCaptcha

A logic vulnerability, dubbed ReBreakCaptcha, which lets you easily bypass Google's ReCaptcha v2 anywhere on the web.


More details in the post: https://east-ee.com/2017/02/28/rebreakcaptcha-breaking-googles-recaptcha-v2-using-google/

## Installation

 - Requires Python 2.6+ or 3.3+.
 - Install the required dependancies using [pip](https://pip.pypa.io/en/stable/).  
 
 ```bash
 pip install -r requirements.txt
 ```
 
## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
