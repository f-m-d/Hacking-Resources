Special thanks
==============

This is the list of people who have contributed to *dnstwist*. Some have
reported bugs or suggested improvements, others have contributed actual code.
If you believe you've been left off, if you'd rather not be listed, or if
you'd prefer a different name be used, please let me know.

(in alphabetical order)

- Charles McCauley
- Christopher Schmidt
- Eugene Kogan
- James Lane
- Julien Rottenberg
- Luke Snyder
- Mario Uher
- Mike Saunders
- Patricia Lipp
- Piotr Chmyłkowski
- Piotr Wojtyła
- Sean Whalen
- Steve Steiner
- Wojtek Słowik

Thank you!
