# Contribution guidelines

Follow the guidelines below to ensure the merge of your pull request

* Add your changes in the CHANGELOG.md
* Send your PR on the develop branch