#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# WPSeku - Wordpress Security Scanner 
# by Momo Outaadi (m4ll0k)

RED = "\x1b[%s;31m"
GREEN = "\x1b[%s;32m"
YELLOW = "\x1b[%s;33m"
BLUE = "\x1b[%s;34m"
WHITE = "\x1b[%s;37m"
RESET = "\x1b[0m"
