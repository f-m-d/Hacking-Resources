"""Support for discovering Wordpress generic parts."""
