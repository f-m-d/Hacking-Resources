"""Support for discovering Wordpress plugins."""
