"""Support for discovering Wordpress themes."""
