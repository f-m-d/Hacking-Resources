"""Support for fingerprinting Wordpress instances."""
