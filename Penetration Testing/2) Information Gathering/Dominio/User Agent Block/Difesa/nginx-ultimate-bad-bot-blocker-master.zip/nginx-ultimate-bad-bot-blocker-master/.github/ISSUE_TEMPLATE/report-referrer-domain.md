---
name: Report Referrer / Domain
about: Reporting of New / False Positive Domains and Referrers (Additions / Removals)
title: "[Referrer-Domain] (add a descriptive title here)"
labels: 'Referrers / Domains'
assignees: 'mitchellkrogza'

---

## Paste the full Domain name / Referrer String here

```

Paste the full Referrer String here (paste in between the ```     ``` markers)

```

## Is this for Addition / Removal?

 - [ ] Addition
 - [ ] Removal


## Post Log Excerpt to show User-Agent behavior (10-20 lines is enough)


```

Post log excerpt here (paste in between the ```     ``` markers)

```

## Additional information

Add any other context about the problem here.
